<a name="v0.0.4"></a>
### v0.0.4 (2014-03-11)


#### Bug Fixes

* Use path.join() to make it run on Windows. ([05346293](http://github.com/karma-runner/karma-cli/commit/053462930de8bcdda800a425d66879df7b5b093f))

<a name="v0.0.3"></a>
### v0.0.3 (2013-11-18)


#### Features

* support Karma 0.10 ([2d7729e0](http://github.com/karma-runner/karma-cli/commit/2d7729e0fff8e5b795839d409dba26ece712bb3b))

<a name="v0.0.2"></a>
### v0.0.2 (2013-11-16)


#### Bug Fixes

* pass correct "basedir" option ([e81749e9](http://github.com/karma-runner/karma-cli/commit/e81749e940d7d75c3e019afa2cbd55f57991e8fe))

