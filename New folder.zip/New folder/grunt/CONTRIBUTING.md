Please see the [Contributing to grunt](http://gruntjs.com/contributing) guide for information on contributing to this project.
