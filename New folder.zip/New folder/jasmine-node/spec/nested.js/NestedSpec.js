describe('jasmine-node-nested.js', function(){
  it('should pass', function(){
    expect(1+2).toEqual(3);
  });
});
