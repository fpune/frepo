# karma-cli

> The [Karma] command line interface.

Install this module if you wanna be able to use `karma` in your command line.

[Karma]: http://karma-runner.github.io
