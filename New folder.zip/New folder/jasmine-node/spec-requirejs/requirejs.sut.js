define(function(){
  return {
    name: 'Subject To Test',
    method: function(input){
      return 1+input;
    }
  };
});
