if(true) {
  
  
  
  
  console.log("except for this one!");/*RemoveLogging:skip*/
}
