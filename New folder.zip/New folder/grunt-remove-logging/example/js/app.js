if(true) {
  console.log("These");
  console.warn('console');
  console.error('statements');
  console.dir({ will: be, removed: "true" });
  console.log("except for this one!");/*RemoveLogging:skip*/
}
